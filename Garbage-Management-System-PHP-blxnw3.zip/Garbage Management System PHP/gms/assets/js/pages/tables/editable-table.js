$(function () {
    $('#mainTable').editableTableWidget();
});